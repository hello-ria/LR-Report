# Weekly status report (2026-10-26)

**Overall health: Red** - 4 tasks are overdue; 2 tasks are blocked.

## Progress
7 of 22 tasks are done and average completion is 47.7%. Status mix: Not Started 8, Done 7, In Progress 5, Blocked 2.

## Overdue tasks
| id | task | owner | due | days_late | notes |
|---|---|---|---|---|---|
| T06 | Vendor board samples ordered | Marcus | 2026-10-14 | 12 | Shipment delayed by supplier two weeks |
| T07 | Firmware API spec | Lena | 2026-10-19 | 7 | Waiting on partner feedback on two endpoints |
| T08 | Build automation scripts | Sam | 2026-10-23 | 3 | Pipeline credentials still pending from IT |
| T20 | Security review | Lena | 2026-10-23 | 3 | Reviewer unavailable until reassigned |

## Blocked tasks
| id | task | owner | due | notes |
|---|---|---|---|---|
| T11 | Test harness setup | Sam | 2026-10-30 | Cannot start until pipeline credentials arrive |
| T20 | Security review | Lena | 2026-10-23 | Reviewer unavailable until reassigned |

## Due in the next 7 days
| id | task | owner | due | status |
|---|---|---|---|---|
| T21 | Training material outline | Marcus | 2026-10-28 | In Progress |
| T11 | Test harness setup | Sam | 2026-10-30 | Blocked |
| T15 | Partner onboarding session | Priya | 2026-10-30 | Not Started |
| T13 | Power BI status dashboard | Priya | 2026-11-02 | In Progress |

## Suggested RAID log entries
- **Issue**: Vendor board samples ordered (T06) is 12 days late. Owner: Marcus. Next step: agree a recovery date. Note: Shipment delayed by supplier two weeks.
- **Issue**: Firmware API spec (T07) is 7 days late. Owner: Lena. Next step: agree a recovery date. Note: Waiting on partner feedback on two endpoints.
- **Issue**: Build automation scripts (T08) is 3 days late. Owner: Sam. Next step: agree a recovery date. Note: Pipeline credentials still pending from IT.
- **Issue**: Security review (T20) is 3 days late. Owner: Lena. Next step: agree a recovery date. Note: Reviewer unavailable until reassigned.
- **Issue**: Test harness setup (T11) is blocked. Owner: Sam. Next step: find the blocker and escalate. Note: Cannot start until pipeline credentials arrive.
- **Risk**: Test harness setup (T11) may slip because it depends on T08. Owner: Sam. Next step: confirm a revised start date.
- **Risk**: Integration milestone 1 (T12) may slip because it depends on T06, T07. Owner: Lena. Next step: confirm a revised start date.
- **Risk**: Performance baseline tests (T16) may slip because it depends on T11. Owner: Sam. Next step: confirm a revised start date.
- **Risk**: Documentation first draft (T18) may slip because it depends on T07. Owner: Marcus. Next step: confirm a revised start date.
- **Risk**: Security review (T20) may slip because it depends on T07. Owner: Lena. Next step: confirm a revised start date.

## Workload by owner
| owner | open_tasks | overdue | blocked |
|---|---|---|---|
| Lena | 4 | 2 | 1 |
| Marcus | 4 | 1 | 0 |
| Priya | 3 | 0 | 0 |
| Sam | 4 | 1 | 1 |
